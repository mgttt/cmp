# PEAR Cache_Lite

[![Build Status](https://travis-ci.org/pear/Cache_Lite.svg)](https://travis-ci.org/pear/Cache_Lite)

This package is [Cache_Lite](http://pear.php.net/package/Cache_Lite).

Please report all new issues via the [PEAR bug tracker](http://pear.php.net/bugs/).

To test this package, run
    
    phpunit tests/

To build, simply

    pear package

To install from scratch

    pear install package.xml

To upgrade

    pear upgrade -f package.xml
